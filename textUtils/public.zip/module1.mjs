import ui, {a, b, d} from './module2.mjs'

console.log(ui)
console.log(a)
console.log(d)