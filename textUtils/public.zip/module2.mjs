const a = "hamza"
const b = "harry"
const c = "arooj"
const d = "monika"

export default c;
export {a};
export {b};
export {d};